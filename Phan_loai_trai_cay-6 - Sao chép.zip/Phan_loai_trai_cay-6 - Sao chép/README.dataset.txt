# Phan_loai_trai_cay > 2026-06-16 7:32pm
https://universe.roboflow.com/duonghungs-workspace/phan_loai_trai_cay-0tshd

Provided by a Roboflow user
License: CC BY 4.0

